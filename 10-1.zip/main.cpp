#include <iostream>
#include <vector>
using namespace std;

void printVector(vector<int> &v) {
  for(int i=0; i<v.size(); i++) {
    cout << v[i] << ' ';
  }
  cout << endl;
}

double getAvg(vector<int> &v) {
  int sum = 0;
  for(int i=0; i<v.size(); i++) {
    sum += v[i];
  }
  return (double)sum/v.size();
}

int main() {
  vector<int> v;

  while(true) {
    cout << "정수를 입력하세요(0을 입력하면 종료)>>" ;
    int num;
    cin >> num;
    if (num == 0) break;
    v.push_back(num);
    printVector(v);
    cout << "평균 : " << getAvg(v) << endl;
  }
}