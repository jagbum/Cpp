#include "book.h"
#include <iostream>
using namespace std;

void Book::set(string title, string author, int year) {
  this -> title = title;
  this -> author = author;
  this -> year = year;
}

void Book::show() {
  cout << year << "년도, " << title << ", " << author << endl;
}