#ifndef BOOK_H
#define BOOK_H
#include <string>
using namespace std;

class Book {
  string title;
  string author;
  int year;
public:
  Book() {};
  Book(string title, string author, int year) : title(title), author(author), year(year) {}
  void set(string title, string author, int year);
  string getAuthor() {return author;}
  int getYear() {return year;}
  void show();
};

#endif