#include "bookmanager.h"
#include <iostream>
#include <vector>
using namespace std;

void BookManager::bookIn() {
  string title, author;
  int year;
  
  cout << "입고할 책을 입력하세요. 년도에 -1을 입력하면 입고를 종료합니다" << endl;
  while(true) {
    cout << "년도>>";
    cin >> year; cin.ignore();
    if(year ==-1) break;
    cout << "책 이름 :";
    getline(cin, title);
    cout << "저자 :";
    getline(cin, author);
    Book b(title, author, year);
    v.push_back(b);  
  }

  cout <<"총 입고된 책은 " << v.size() <<"권 입니다." << endl;
}

void BookManager:: searchByAuthor() {
  cout << " 검색할 저자 이름은?";
  string author;
  getline(cin, author);
  for(int i =0; i< v.size(); i++) {
    Book b = v[i];
    if(b.getAuthor()== author)
      b.show();
  }
}

void BookManager:: searchByYear() {
  cout << " 검색할 년도는?";
  int year;
  cin >> year; cin.ignore();
  for(int i =0; i< v.size(); i++) {
    Book b = v[i];
    if(b.getYear() == year)
      b.show();
  }
}

void BookManager::run() {
  while(true){
    cout << "메뉴(1: 책추가, 2: 저자검색, 3: 년도검색)";
    int menu;
    cin >> menu; cin.ignore();
    if(menu == 0) break;
    switch(menu) {
      case 1: bookIn(); break;
      case 2: searchByAuthor(); break;
      case 3: searchByYear(); break;
      default: cout<< "다시입력" << endl;
    }
  }
  bookIn();
  searchByAuthor();
  searchByYear();
}