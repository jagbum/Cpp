#ifndef BOOKMANAGER_H
#define BOOKMANAGER_H
#include "book.h"
#include <vector>

class BookManager {
  vector<Book> v;
  void searchByAuthor();
  void searchByYear();
  void bookIn();
public:
 void run();
};

#endif