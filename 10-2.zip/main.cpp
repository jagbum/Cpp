#include <iostream>
#include "bookmanager.h"
using namespace std;

int main() {
  BookManager bookMan;
  bookMan.run();
}