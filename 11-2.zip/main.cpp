#include <iostream>
#include <string>
#include "phone.h"
using namespace std;

int main() {
  Phone girl, boy;
  cin >> girl >> boy; //전화 번호를 키보드로부터 읽는다.
  cout << girl << endl << boy << endl; // 전화 번호를 출력한다.
}