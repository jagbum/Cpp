#include "phone.h"


//cin >> boy; --> operator >> (cin, boy)
istream& operator >> (istream& ins, Phone& a) {
  cout << "이름:" ;
  ins >>a.name;
  getline(ins,a.name);
  cout << "전화번호:";
  getline(ins,a.telnum);
  cout << "주소:";
  getline(ins,a.address);
  return ins;
}

//cout << phone; --> operator <<(cout,phone)
ostream& operator << (ostream& outs, Phone a) {
  outs << "(" << a. name <<"," << a.telnum << "," <<a.address<< ")" ;
  return outs;
}