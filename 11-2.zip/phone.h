#ifndef PHONE_H
#define PHONE_H
#include <iostream>
#include <string>
using namespace std;

class Phone { // 전화 번호를 표현하는 클래스
 string name;
 string telnum;
 string address;
public:
 Phone(string name="", string telnum="", string address="") {
 this->name = name;
 this->telnum = telnum;
 this->address = address;
 }
 friend istream& operator >> (istream& ins, Phone& a);
 friend ostream& operator << (ostream& outs, Phone a);
};

istream& operator >> (istream& ins, Phone& a);
ostream& operator << (ostream& outs, Phone a);

#endif