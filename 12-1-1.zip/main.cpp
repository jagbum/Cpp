#include <iostream>
#include <fstream>
#include <cctype> //int toupper() // 소문자 -> 대문자 (char) 필요
#include <string>
using namespace std;

//command line argument
int main(int argc, char* argv[]) {
  string file ;
  string ufile ;

  if(argc == 3) {
    file = argv[1];
    ufile = argv[2];
  } else {
    cout << "usage: " << argv[0] <<  "inputfilename outputfilename" <<endl;
    return 0;
  }
  
  ifstream fin(file);
  if(!fin) {
    cout << file << " 읽기 오류" << endl;
    return 0;
  }
  ofstream fout(ufile);
  if(!fout) {
    cout << ufile << " 열기 오류" << endl;
    return 0;
  }

  cout<< "읽기 시작"<< endl;

  int c;
  while((c = fin.get()) != EOF) {
    int t = toupper(c); //소문자 -> 대문자  tolower 소문자 ->대문자
    cout << char (t);
    fout.put(t);
  }

  fin.close();
  fout.close();
}