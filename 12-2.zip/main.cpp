#include <iostream>
#include "words.h"

int main() {
  words w;
  w.run();
}