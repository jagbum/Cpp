#include "words.h"

words :: words(){
  fin.open("words.txt");
  if(!fin){
    cout << "words.txt 열기 실패" << endl;
    exit(0);
  }
  string word;
  while(getline(fin, word)){
    wordvector.push_back(word);
  }
  cout << "words 파일 읽기 완료" << endl;
}

bool words::exist(string word) {
  for(int i=0; i<wordvector.size(); i++) {
    if(word == wordvector[i])
      return true;
  }
  return false;
}

void words:: search(string word) {
  int length = word.length();
  for(int i=0; i<wordvector.size(); i++) {
    if(wordvector[i].size() == length) {
      if(word == wordvector[i]) continue;

      for(int j=0; j<length; j++) {
        string orig = word;
        string dic_word = wordvector[i];
        orig[j] = dic_word[j] = '*';
        if(orig == dic_word){
          cout << wordvector[i] << endl;
        break;
        }
      }
    }
  }
}

words::~words() {
  fin.close();
}

void words::run() {
  cout<< "단어 입력" << endl;
  while(true) {
    cout << "단어 >>";
    string word;
    getline(cin, word);
    if(word == "exit") return;
    if(!exist(word))
      cout << word << "단어 없음" << endl;
    search(word);
  }
}