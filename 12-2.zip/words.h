#ifndef WORDS_H
#define WORDS_H
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
using namespace std;

class words {
  ifstream fin;
  vector<string> wordvector;
  bool exist(string word);
  void search(string word);
public:
  words();
  ~words();
  void run();
};


#endif