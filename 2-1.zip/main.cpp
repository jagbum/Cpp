#include <iostream>
using namespace std;

int main() {
  cout << "6개의 실수를 입력하시오" << endl  ;
  double max, min, input;

  cin >> input;

  max  = min = input;

  for(int i=0; i<5; i++) {
    cin >> input;

    //최대값
    if(input > max) {
      max = input;  
    }

    // 최소값
    if(input < min) {
     min  = input;
    }
  }

  cout << "가장큰수" << max << endl;
  cout << "가장작은수" << min << endl;


}