#include <iostream>
using namespace std;

int main() {
  char name[20];
  char adress[128];
  int age;

  cout << "이름:";
  cin >> name ;
  cout << "주소:";
  cin.ignore(10, '\n');
  cin.getline(adress, 128, '\n');
  cout << "나이:";
  cin >> age;

  cout << name <<"("<< age <<")"<< adress << endl;
  
}