#include <iostream>
#include <string>
using namespace std;

int main() {
  
  string sName, sAddr;
  int sAge;
  cout << "이름";
  cin >> sName;
  cout <<"주소";
  cin.ignore(10, '\n');
  getline(cin, sAddr);//string
  cout << "나이";
  cin >> sAge;
  
  cout << sName << sAge/10 <<"0대"<< sAddr<< endl;
  //cout << sName << sAge << sAddr<< endl;

  return 0; 
}