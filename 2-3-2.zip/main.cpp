#include <iostream>
using namespace std;

bool checkInputError() {
  if(cin.fail()) {
    cin.clear();
    cin.ignore(100,'\n');
    cout << "입력 오류" <<endl;
    return true;
  } else
  return false;
}

int main() {
  cout << "**중국집**";
  int menu, num;
  while(true){
    cout << "짬뽕:1, 짜장:2, 탕수육:3, 종료:4 >>";
    cin >> menu;
    if (checkInputError()) {
      continue;
    }

    if(menu <1 || menu >4) {
      cout << " 다시입력" << endl;
      continue;
    }
    if(menu == 4) {
      cout << "영업종료"<< endl;
      return 0;
    }
    if (menu < 3) {
      cout << "몇인분";
    } else {
      cout << "몇개";
    }
    cin >> num;
    if (checkInputError()) {
      continue;
    }
    switch (menu) {
      case 1: 
      cout << "짬뽕" << num << "인분 나왔습니다.";
      case 2:
      cout << "짜장면" << num << "인분 나왔습니다.";
      case 3:
      cout << "탕수육" << num << "개 나왔습니다." ;
      break ;

    }
  }  
}