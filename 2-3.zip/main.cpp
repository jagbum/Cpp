#include <iostream>
using namespace std;




int main() {
  cout << "**중국집**";
  double num;
  double ss;
  while(true){
    cout << "짬뽕:1, 짜장:2, 탕수육:3, 종료:4 >>";
    cin >> num;

    if (num == 1) {
      cout << "몇인분?";
      cin >> ss;
      cout << "짬뽕" << ss << "인분 나왔습니다.";
      return 0;    
    }
    else if (num == 2) {
      cout << "몇인분?";
      cin >> ss;
      cout << "짜장면" << ss << "인분 나왔습니다.";
      return 0;
    }
    else if (num == 3) {
      cout << "몇개?";
      cin >> ss;
      cout << "탕수육" << ss << "개 나왔습니다.";
      return 0;
    }
    else if (num == 4) {
      cout << "영업종료";
      return 0;
    }
    else if (num >= 7){ 
      cout << "잘못 입력했습니다.";
    }
  }  
}
