#include <iostream>
#include <string>
using namespace std;

class Account {
  private:
    string name;
    int id;
    int balance;
  public:
    Account(string _name, int _id, int _balance);
    Account();
    void deposit(int dep);
    string getOwner();
    int withdraw(int wd);
    int inquiry();
};

Account::Account():Account("aa",0,0) {
  /*name = "aa";
  id = 0;
  balance = 0;*/
}

Account::Account(string _name, int _id, int _balance): name(_name), id(_id), balance(0){
  /*name = _name;
  id = _id;
  balance = _balance;*/
  deposit(_balance);
}

void Account::deposit(int dep) {
  if(dep < 0) return;
  balance += dep;
}

string Account::getOwner(){
  return name;
}

int Account::withdraw(int wd) {
  if(balance >= wd){
  balance -= wd;
  return wd;
  }
  else {
    return 0;
  }
}

int Account::inquiry() {
  return balance;
}

int main() {
  Account a("youn", 1, 5000);
  a.deposit(50000);
  cout << a.getOwner() << "의 잔액은" << a.inquiry() <<endl;
  int money = a.withdraw(20000); 
  cout << a.getOwner() << "의 잔액은" << a.inquiry() <<endl;

  Account b("qw",2,-2000);
  cout << b.inquiry() << endl;
}

  
