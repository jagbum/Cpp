#include "random.h"
#include <cstdlib>
#include <ctime>
using namespace std;

Random::Random() {
  srand((unsigned)time(0));
}
int Random::next() {
  
  return rand();
}

int Random::nextInRange(int s, int e) {
  return rand()%(e-s)+s;
}