#include <iostream>
#include <string>
using namespace std;

int main() {
  string text;
  cout << "문자열 입력";
  getline(cin, text);

  int counts['z'-'a'+1];
  int index =0;
  for(char c = 'a'; c <='z'; c++){
    while(true){
      index = text.find(c, index);
      if(index == -1) break;
      counts[c - 'a']++;
      index++;  
    }
    index = 0;
  }
  for(int i =0; i<text.length();i++){
    if(text[i] >= 'a' && text[i] <= 'z')
    counts[text[i] - 'a']++;
  }

  for(char c = 'a'; c<='z'; c++) {
    if(counts[c-'a'] !=0)
      cout << c << ":" << counts[c-'a']<<endl;
  }

}