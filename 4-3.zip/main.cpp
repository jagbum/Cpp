#include <iostream>
using namespace std;
#include "CoffeeVendingMachine.h"

int main() {
  CoffeeVendingMachine cvm;
  cvm.run();
}