#include <iostream>
using namespace std;
/* call by address
void half(double* n){
  *n =*n/2;
}*/

void half(double &a) {
  a = a/2;`
}


int main() {
 double n = 20;
 half(n); //half(&n)
 cout << n << endl;
} 