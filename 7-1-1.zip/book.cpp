#include "book.h"

Book& Book::operator+=(int op2){
  price+= op2;
  return *this;
}

Book& Book::operator-=(int op2){
  price-= op2;
  return *this;
}

bool Book::operator!(){
  if(this->price ==0)return true;
else return false;
}