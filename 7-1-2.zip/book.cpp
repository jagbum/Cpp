#include "book.h"

bool operator < (string name, Book book) {
  if(name <book.title) return true;
  else return false;
}

Book& operator+=(Book& op1, int op2){
  op1.price += op2;
  return op1;
}

Book& operator-=(Book &op1, int op2){
  op1.price -= op2;
  return op1;
}