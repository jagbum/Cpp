#include <iostream>
using namespace std;
#include "book.h"

int main() {
 Book a("청춘", 20000, 300), b("미래", 30000, 500);
 a += 500; // 책 a의 가격 500원 증가
 b -= 500; // 책 b의 가격 500원 감소
 a.show();
 b.show();

 string bookname;
 cout << "책 이름을 입력하세요>>";
 getline(cin, bookname);
 if(bookname < a)
 cout << a.getTitle() << "이 " << bookname << "보다 뒤에 있구나!" << endl;
}