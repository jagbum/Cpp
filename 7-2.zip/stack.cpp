#include "stack.h"

Stack& Stack::operator << (int n) {
  if(tos >= size) return *this;
  mem[tos++] = n;
  return *this;
}

Stack& Stack::operator >> (int& n) {
  if(tos == 0) return *this;
  n = mem[--tos];
  return *this;
}

bool Stack::operator !() {
  if(tos == 0) return true;
  else return false;
}