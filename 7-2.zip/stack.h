#ifndef STACK_H
#define STACK_H

class Stack {
  int size;
  int tos;
  int* mem;
public:
  Stack(int size = 10){
    this->size = size;
    mem = new int[size];
    tos = 0;
  }
  ~Stack() {
    delete []mem;
  }
  Stack& operator << (int n);
  Stack& operator >> (int& n);
  bool operator !();
};

#endif