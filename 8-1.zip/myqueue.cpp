#include "myqueue.h"

MyQueue :: MyQueue(int capacity) : BaseArray(capacity) {
  head = 0;
  tail = -1;
  size = 0;
}

int MyQueue :: capacity() {
  return getCapacity();
}
int MyQueue :: length() {
  return size;
}
void MyQueue :: enqueue(int n) {
  if(size == capacity()) return; //큐 풀
  put(head, n);
  head++;
  head = head % capacity();
  size++;
}

int MyQueue :: dequeue() {
  if(size ==0) return -1; //큐 empty
  tail++;
  size--;
  tail = tail % capacity();
  return get(tail);
}