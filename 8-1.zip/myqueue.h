#ifndef MYQUEUE_H
#define MYQUEUE_H
#include "basearray.h"

class MyQueue : public BaseArray {
  int head;
  int tail;
  int size;
public:
  MyQueue(int capacity);
  void enqueue(int n);
  int dequeue();
  int capacity();
  int length();
};

#endif