#include "mystack.h"

int MyStack :: capacity() {
  return getCapacity();
}

int MyStack :: length() {
  return tos;
}

void MyStack::push(int n) {
  if(tos == capacity()) return;
  put(tos++, n);
}

int MyStack :: pop(){
  if(tos == 0) return -1;
  return get(--tos);
  /* 
  --tos
  return(tos)
   */
} 

MyStack :: MyStack(int capacity) : BaseArray(capacity) {
  tos = 0;
}