#ifndef MYSTACK_H
#define MYSTACK_H
#include "basearray.h"

class MyStack : public BaseArray {
  int tos;
public:  
  MyStack(int capacity);
  void push(int n);
  int pop();
  int capacity();
  int length();
};

#endif