#include <iostream>
#include "shape.h"
#include "triangular.h"
#include "oval.h"
#include "rect.h"

using namespace std;

int main() {
 Shape *p[3];
 p[0] = new Oval("빈대떡", 10, 20);
 p[1] = new Rect("찰떡", 30, 40);
 p[2] = new Triangular("토스트", 30, 40);
 for(int i=0; i<3; i++)
 cout << p[i]->getName() << " 넓이는 " << p[i]->getArea() << endl;
 for(int i=0; i<3; i++) delete p[i];

//2번
// Shape s; <- 추상이라 불가
// cout << s.getName() << " : " << s.getArea() << endl; 
}
