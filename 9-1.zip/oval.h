#ifndef OVAL_H
#define OVAL_H
#include "shape.h"

class Oval : public Shape  {
  public:
    Oval(string name, int width, int height) : Shape(name, width, height) {}
    virtual double getArea() {return 3.14* width* height;}
};

#endif