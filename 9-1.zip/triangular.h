#ifndef TRIANGULAR_H
#define TRIANGULAR_H
#include "shape.h"

class Triangular : public Shape {
  public:
    Triangular(string name, int width, int height) : Shape(name, width, height) {}
    double getArea() {return width * height *0.5;}
};

#endif