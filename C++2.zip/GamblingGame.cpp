#include "GamblingGame.h" // GamblingGame.h를 include
#include "Player.h" // Player.h를 include
#include <iostream> // iostream 클래스 사용위한 헤더파일
#include <ctime> // rand(), srand() 사용위한 헤더파일
using namespace std; // std 공간에 선언된 이름에 std::생략

int GamblingGame::start(){ // 멤버함수 start() 구현 
  Player *p; // Player타입의 객체에 대한 포인터 변수 p선언
  int card[3]; // 3개의 정수 배열 card 생성  
  int num; // num 정수 변수 선언
  srand((unsigned)time(0)); // 매번 다른 난수를 생성하기 위해 seed값을 현재 시간으로 주어 시간이 지나면서 seed값이 변화
  cout << "*** 게임을 시작 합니다. ***"<< endl; // *** 게임을 시작 합니다. *** 출력후 다음줄로 넘어감
  cout << "참여 선수 인원을 입력하세요 : " ; // "참여 선수 인원을 입력하세요 : " 출력
  cin >> num; // 정수 num 입력
  p = new Player[num]; // 크기가 'num'인 Player 객체 배열 동적 할당
  for(int i = 0; i < num ; i++){ // 정수 i = 0 부터 "num" 미만의 값까지 반복 실행
    cout << i+1 <<"번째 선수 이름:"; // 'i+1'번쨰 선수이름: 출력
    p[i].setName(); // p[i]의 Player 객체의 멤버함수 setName() 실행 (name 입력) 
    cin.ignore(); // 입력버퍼에서 '\n' 삭제
  } //for문 끝
  while(true){ // while문 반복실행
    for(int i = 0; i < num ; i++){ //  정수 i = 0 부터 "num" 미만의 값까지 반복 실행
      cout << p[i].getName() << ": <엔터>";// 'p[i]의 Player 객체의 멤버함수 getName() 실행 (name 반환)':<엔터> 출력
      cin.ignore(); // 입력버퍼에서 '\n' 삭제
      cout << endl; // 다음줄로 넘어감
    
      for (int n=0; n < 3; n++){ // 정수 n = 0 부터 2까지 반복 실행
        card[n] = rand() % 4+1; // card[0], card[1], card[2]에 1부터 4까지의 수를 무작위로 배정
      } // for문 끝
      cout << '\t' << '\t' << card[0] << "   " << card[1] << "   " << card[2] << "     "; // 'card[0]' 'card[1]' 'card[2]'출력
      if(card[0]==card[1] && card[0]==card[2] ){ // card[0]=card[1]=card[2]인 경우의 if문
        cout << p[i].getName() << "님 승리!!!" << endl << "*** 게임을 종료 합니다. ***"; //'p[i]의 이름'님 승리 출력 후 다음줄로 넘어가 *** 게임을 종료 합니다. *** 출력
        return 0; // 정상종료
      } // if문 끝
      else { // card[0]=card[1]=card[2]가 아닌 경우의 else문
      cout << "아쉽군요!" << endl; // 아쉽군요! 출력 후 다음줄로 넘어감
      } // else문 끝
    } // for문 끝
  } // while 문 끝
} // 멤버함수 start() 구현 끝