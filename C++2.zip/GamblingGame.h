#ifndef GAMBLINGGAME_H // GamblingGame.h 중복 include 방지
#define GAMBLINGGAME_H // GamblingGame.h 중복 include 방지 GAMBLINGGAME_H 상수 정의

class GamblingGame { // GamblingGame 클래스 선언
  public: // 멤버에 대한 접근지정자 public
  int start(); // 멤버함수 start() 선언
}; // GamblingGame 클래스 선언 끝

#endif // GamblingGame.h 중복 include 방지 GamblingGame.h가 두번쨰 include 될 때 부터 #endif 문 밖으로 빠져나옴