#include "Player.h" // Player.h를 include 
#include <iostream> // c++ 표준입출력 클래스 사용위한 헤더파일

void Player::setName(){ // 멤버함수 setName() 구현 
  cin >> name; // name 입력
} // 멤버함수 setName() 구현 끝

string Player::getName(){ // 멤버함수 getName() 구현
  return name; // name 반환
} // 멤버함수 getName() 구현 끝