#ifndef PLAYER_H // Player.h 중복 include 방지
#define PLAYER_H // Player.h 중복 include 방지 PLAYER_H 상수 정의
#include <string> // string 클래스 사용위한 헤더파일 
using namespace std; // std 공간에 선언된 이름에 std::생략

class Player { // Player 클래스 선언
  string name; // 멤버변수 name선언
  public: // 멤버에 대한 접근지정자 public
  void setName(); // 멤버함수 setName() 선언
  string getName(); // 멤버함수 getName() 선언
}; // Player 클래스 선언 끝

#endif // Player.h 중복 include 방지 Player.h가 두번쨰 include  될 때 부터 #endif 문 밖으로 빠져나옴