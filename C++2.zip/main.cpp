#include "GamblingGame.h" // GamblingGame.h를 include

int main() { // main() 함수 실행
  GamblingGame g; // GamblingGame 타입의 객체 g 선언
  g.start(); //  GamblingGame 타입의 객체 g의 멤버함수 start() 실행
} // main 함수 끝
